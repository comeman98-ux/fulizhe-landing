import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: 'class',
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // 背景颜色：明亮模式使用淡绿色，暗色模式保持深色但略带冷色调，保证与主蓝色协调
        background: {
          DEFAULT: '#f0fff4',
          dark: '#0b1220',
        },
      },
    },
  },
};

export default config;
